var app = angular.module('MyApp',[]);
app.controller('addController',function()


{
	var AddInList=this;
AddInList.products=

[
/*

{username: 'sam',content:'salt les'} ,
*/
{
pic:'pic/download.jpg',
product_name:'Iphone',
description:'simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the  when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries but also the leap into electronic typesetting remaining essentially unchanged. It was popularised',
price: 350 ,
width:'220px'
},


{

pic:'pic/hawawi.jpg',
product_name:'Hawawi',
description:'simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the  when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries but also the leap into electronic typesetting remaining essentially unchanged. It was popularised',
price: 250 ,
width:'220px'


},






{
pic:'pic/dow.jpg',
product_name:'Samsung',
description:'simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the  when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries but also the leap into electronic typesetting remaining essentially unchanged. It was popularised',
price: 180,
width:'220px'


},















];


AddInList.AddContent=function()
{

AddInList.users.push({username:AddInList.username,content:AddInList.content})

AddInList.username='';
AddInList.content='';


};



});


app.controller('PanelsController',function()
{

this.tab = 1;
this.SetTab=function(InSet)

{
this.tab = InSet ;

};


this.IsSelected=function(select)
{

return this.tab===select;



};





});








